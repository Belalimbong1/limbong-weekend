<footer>
    <p><b>Limbong Weekend - Street Food</b></p>
    <p>Jl. besar Tigaras Simantin 3, Pane, Kab. Simalungun, Sumatera Utara</p>
    <p>Phone: 082161045625</p>
  
    <div class="icon-contact">   
    </div>
    
</footer>